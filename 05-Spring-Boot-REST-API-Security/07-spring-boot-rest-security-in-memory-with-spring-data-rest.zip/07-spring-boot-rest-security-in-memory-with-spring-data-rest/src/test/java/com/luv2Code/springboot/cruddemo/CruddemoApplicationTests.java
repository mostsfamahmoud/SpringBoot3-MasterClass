package com.luv2Code.springboot.cruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
